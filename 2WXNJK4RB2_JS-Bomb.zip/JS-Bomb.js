let timer = document.getElementById("timer");
let defuse = document.getElementById("defuser");

let count = 10;

let a = setInterval(function() {
    count = count - 1;
    timer.textContent = count;
    if (count === 0) {
        timer.textContent = "BOOM!!";
        clearInterval(a);
    }
}, 1000);

defuse.addEventListener("keydown", function(event) {
    let b = defuse.value;
    if (event.key === "Enter" && b === "defuse" && count !== 0) {
        timer.textContent = "Suresh You did it";
        timer.style.color = "red";
        clearInterval(a);
    }
});